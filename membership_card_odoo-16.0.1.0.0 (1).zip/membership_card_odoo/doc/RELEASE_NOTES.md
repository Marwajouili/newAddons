## Module <membership_card_odoo>

#### 06.04.2023
#### Version 16.0.1.0.0
#### ADD
Initial Commit for Membership Card





